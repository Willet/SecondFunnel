__all__ = ['handler503']

handler503 = 'maintenancemode.views.defaults.temporary_unavailable'